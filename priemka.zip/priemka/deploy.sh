#!/bin/bash

set -e

echo "📦 Обновление системы..."
sudo apt update
sudo apt install -y python3-pip python3-venv nginx

echo "🚀 Разворачивание проекта..."
cd /var/www/
sudo mkdir -p priemka
sudo chown $USER:$USER priemka
cd priemka

git clone https://github.com/your-username/priemka.git .

python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

deactivate

echo "🔧 Настройка systemd..."
sudo tee /etc/systemd/system/priemka.service > /dev/null <<EOF
[Unit]
Description=Gunicorn instance to serve priemka
After=network.target

[Service]
User=$USER
Group=$USER
WorkingDirectory=/var/www/priemka
ExecStart=/var/www/priemka/gunicorn_start.sh

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable priemka
sudo systemctl start priemka

echo "🌐 Настройка Nginx..."
sudo tee /etc/nginx/sites-available/priemka > /dev/null <<EOF
server {
    listen 80;
    server_name _;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    }
}
EOF

sudo ln -sf /etc/nginx/sites-available/priemka /etc/nginx/sites-enabled/priemka
sudo rm -f /etc/nginx/sites-enabled/default
sudo systemctl restart nginx

echo "✅ Установка завершена! Ваш сайт доступен на порту 80."