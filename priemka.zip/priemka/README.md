# Priemka

Flask-приложение для приёма заявок через веб-форму и сохранения их в текстовые файлы.

## Установка и запуск

### 1. Клонировать репозиторий:

```bash
git clone https://github.com/your-username/priemka.git
cd priemka
```

### 2. Создать виртуальное окружение:

```bash
python3 -m venv venv
source venv/bin/activate
```

### 3. Установить зависимости:

```bash
pip install -r requirements.txt
```

### 4. Запустить локально:

```bash
python3 app.py
```

или через Gunicorn:

```bash
./gunicorn_start.sh
```

## Продакшн установка (Gunicorn + Nginx)
(см. полную инструкцию в README)