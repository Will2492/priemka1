from flask import Flask, request
import os
import time

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        data = request.form.get('request')
        save_dir = 'заявки'
        os.makedirs(save_dir, exist_ok=True)
        filename = os.path.join(save_dir, f'{int(time.time())}.txt')
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(data)
        return '✅ Заявка сохранена!'
    return '''
        <form method="POST">
            <textarea name="request" rows="5" cols="30"></textarea><br>
            <button type="submit">Отправить заявку</button>
        </form>
    '''

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000)